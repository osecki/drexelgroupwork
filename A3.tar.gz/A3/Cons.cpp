/**
 * Program:  Cons.cpp
 * Authors:  Group 7: Jordan Osecki, Geoff Oxholm, Rich Price, Alimoor Reza
 * Class:    CS550, Assignment 2, Spring 2009
**/

#include "Cons.h"
#include "Expr.h"
#include "List.h"
#include <map>

Cons::Cons(Expr* op1, Expr* op2)
{
    op1_ = op1;
    op2_ = op2;
}

Element* Cons::eval(map<string,Element*> NT, map<string,Proc*> FT, Memory &memory) const
{
    // Calls the cons() function from List
    List* newL = (List*)op1_->eval(NT,FT,memory);
    Element* two = (Element*)op2_->eval(NT,FT,memory);

    int address = memory.cons(two, newL->getAddress(), NT);
    return new List(address);
}
