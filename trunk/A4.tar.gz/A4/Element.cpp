/**
 * Program:  Element.cpp
 * Authors:  Group 7: Jordan Osecki, Geoff Oxholm, Alimoor Reza
 * Class:    CS550, Assignment 4, Spring 2009
**/
#include "Number.h"
#include "Element.h"

int Element::listp() {
    return 0;
}

int Element::intp() {
    return 0;
}
